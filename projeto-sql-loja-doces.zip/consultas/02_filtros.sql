-- Vendas feitas por João
SELECT * FROM vendas WHERE cliente_id = 1;

-- Produtos com preço acima de 5 reais
SELECT * FROM produtos WHERE preco > 5;
