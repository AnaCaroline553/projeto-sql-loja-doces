-- Ver todos os clientes
SELECT * FROM clientes;

-- Ver todos os produtos
SELECT * FROM produtos;

-- Ver todas as vendas
SELECT * FROM vendas;
