# Projeto SQL - Loja de Doces da Ana 🍬

Esse projeto simula uma lojinha de doces com dados fictícios de clientes, produtos e vendas.

## Objetivos
- Criar e popular tabelas em SQL
- Fazer consultas simples e intermediárias
- Aprender conceitos básicos de SQL na prática

## Estrutura do Projeto

```
projeto-sql-loja-doces/
├── README.md
├── dados/
│   └── criar_tabelas_e_dados.sql
├── consultas/
│   ├── 01_visualizar_dados.sql
│   ├── 02_filtros.sql
│   ├── 03_joins.sql
│   └── 04_analises.sql
```

## Ferramentas utilizadas
- SQLite (testado no DB Browser for SQLite)
- GitHub

## Consultas realizadas
- Visualização de dados
- Filtros simples
- JOINs entre tabelas
- Agregações com GROUP BY
